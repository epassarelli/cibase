<div class="featured-boxes featured-boxes-style-2">
							<div class="row">
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200" style="animation-delay: 200ms;">
									<div class="featured-box featured-box-effect-4" style="height: 283px;">
										<div class="box-content">
											<i class="icon-featured icon-screen-tablet icons text-color-primary bg-color-grey-scale-1"></i>
											<h4 class="font-weight-bold">Mobile Apps</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400" style="animation-delay: 400ms;">
									<div class="featured-box featured-box-effect-4" style="height: 283px;">
										<div class="box-content">
											<i class="icon-featured icon-layers icons text-color-primary bg-color-grey-scale-1"></i>
											<h4 class="font-weight-bold">Creative Websites</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="600" style="animation-delay: 600ms;">
									<div class="featured-box featured-box-effect-4" style="height: 283px;">
										<div class="box-content">
											<i class="icon-featured icon-magnifier icons text-color-primary bg-color-grey-scale-1"></i>
											<h4 class="font-weight-bold">SEO Optimization</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1000" style="animation-delay: 1000ms;">
									<div class="featured-box featured-box-effect-4" style="height: 283px;">
										<div class="box-content">
											<i class="icon-featured icon-screen-desktop icons text-color-primary bg-color-grey-scale-1"></i>
											<h4 class="font-weight-bold">Brand Solutions</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="800" style="animation-delay: 800ms;">
									<div class="featured-box featured-box-effect-4" style="height: 283px;">
										<div class="box-content">
											<i class="icon-featured icon-doc icons text-color-primary bg-color-grey-scale-1"></i>
											<h4 class="font-weight-bold">HTML5 / CSS3 / JS</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="600" style="animation-delay: 600ms;">
									<div class="featured-box featured-box-effect-4" style="height: 283px;">
										<div class="box-content">
											<i class="icon-featured icon-menu icons text-color-primary bg-color-grey-scale-1"></i>
											<h4 class="font-weight-bold">Buttons</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
							</div>
						</div>