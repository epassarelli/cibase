<div class="container">

						<div class="row">
							<div class="col-md-10 py-3 mx-md-auto">
								<div class="row pt-2 clearfix">
									<div class="col-lg-6">
										<div class="feature-box feature-box-style-2 reverse appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" style="animation-delay: 100ms;">
											<div class="feature-box-icon">
												<i class="icon-user-following icons text-color-light"></i>
											</div>
											<div class="feature-box-info">
												<h4 class="mb-2 text-5 text-color-light">Customer Support</h4>
												<p class="mb-4 text-color-light opacity-6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" style="animation-delay: 100ms;">
											<div class="feature-box-icon">
												<i class="icon-layers icons text-color-light"></i>
											</div>
											<div class="feature-box-info">
												<h4 class="mb-2 text-5 text-color-light">Sliders</h4>
												<p class="mb-4 text-color-light opacity-6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="feature-box feature-box-style-2 reverse appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200" style="animation-delay: 200ms;">
											<div class="feature-box-icon">
												<i class="icon-calculator icons text-color-light"></i>
											</div>
											<div class="feature-box-info">
												<h4 class="mb-2 text-5 text-color-light">HTML5</h4>
												<p class="mb-4 text-color-light opacity-6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="200" style="animation-delay: 200ms;">
											<div class="feature-box-icon">
												<i class="icon-star icons text-color-light"></i>
											</div>
											<div class="feature-box-info">
												<h4 class="mb-2 text-5 text-color-light">Icons</h4>
												<p class="mb-4 text-color-light opacity-6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="feature-box feature-box-style-2 reverse appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400" style="animation-delay: 400ms;">
											<div class="feature-box-icon">
												<i class="icon-drop icons text-color-light"></i>
											</div>
											<div class="feature-box-info">
												<h4 class="mb-2 text-5 text-color-light">Colors</h4>
												<p class="mb-0 text-color-light opacity-6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="400" style="animation-delay: 400ms;">
											<div class="feature-box-icon">
												<i class="icon-mouse icons text-color-light"></i>
											</div>
											<div class="feature-box-info">
												<h4 class="mb-2 text-5 text-color-light">Buttons</h4>
												<p class="mb-0 text-color-light opacity-6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

					</div>