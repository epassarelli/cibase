<div class="row">
						<div class="featured-boxes featured-boxes-style-2">
							<div class="row">
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="700" style="animation-delay: 700ms;">
									<div class="featured-box featured-box-effect-4" style="height: 231px;">
										<div class="box-content">
											<i class="icon-featured icon-screen-tablet icons text-color-primary bg-color-grey"></i>
											<h4 class="font-weight-bold">Mobile Apps</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="900" style="animation-delay: 900ms;">
									<div class="featured-box featured-box-effect-4" style="height: 231px;">
										<div class="box-content">
											<i class="icon-featured icon-layers icons text-color-light bg-color-primary"></i>
											<h4 class="font-weight-bold">Creative Websites</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="1100" style="animation-delay: 1100ms;">
									<div class="featured-box featured-box-effect-4" style="height: 231px;">
										<div class="box-content">
											<i class="icon-featured icon-magnifier icons text-color-primary bg-color-grey"></i>
											<h4 class="font-weight-bold">SEO Optimization</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1500" style="animation-delay: 1500ms;">
									<div class="featured-box featured-box-effect-4" style="height: 231px;">
										<div class="box-content">
											<i class="icon-featured icon-screen-desktop icons text-color-light bg-color-primary"></i>
											<h4 class="font-weight-bold">Brand Solutions</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1300" style="animation-delay: 1300ms;">
									<div class="featured-box featured-box-effect-4" style="height: 231px;">
										<div class="box-content">
											<i class="icon-featured icon-doc icons text-color-primary bg-color-grey"></i>
											<h4 class="font-weight-bold">HTML5 / CSS3 / JS</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1100" style="animation-delay: 1100ms;">
									<div class="featured-box featured-box-effect-4" style="height: 231px;">
										<div class="box-content">
											<i class="icon-featured icon-menu icons text-color-light bg-color-primary"></i>
											<h4 class="font-weight-bold">Buttons</h4>
											<p class="px-3">Lorem ipsum dolor sit amt, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>