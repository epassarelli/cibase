<div class="container container-lg py-5 my-5">
					<div class="row justify-content-center">
						<div class="col-xl-9 text-center">
							<h2 class="font-weight-bold text-11 appear-animation animated fadeInUpShorter appear-animation-visible" data-appear-animation="fadeInUpShorter" style="animation-delay: 100ms;">We are Porto, we are Awesome</h2>
							<p class="line-height-9 text-4 opacity-9 appear-animation animated fadeInUpShorter appear-animation-visible" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200" style="animation-delay: 200ms;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras volutpat id sapien ac varius. Fusce hendrerit ligula a consectetur ullamcorper. Vestibulum varius pharetra lorem, in maximus libero placerat sed. In a lectus vel mauris tempor lobortis feugiat sed magna.</p>
						</div>
					</div>
					<div class="row featured-boxes featured-boxes-style-4">
						<div class="col-sm-6 col-lg-3 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="400" style="animation-delay: 400ms;">
							<div class="featured-box mb-lg-0" style="height: 155px;">
								<div class="box-content px-lg-1 px-xl-5">
									<i class="icon-featured icons icon-bubbles text-color-primary text-11"></i>
									<h4 class="font-weight-bold text-5 mb-3">Strategy</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-lg-3 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="200" style="animation-delay: 200ms;">
							<div class="featured-box mb-lg-0" style="height: 155px;">
								<div class="box-content px-lg-1 px-xl-5">
									<i class="icon-featured icons icon-organization text-color-primary text-11"></i>
									<h4 class="font-weight-bold text-5 mb-3">Plan Everything</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-lg-3 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200" style="animation-delay: 200ms;">
							<div class="featured-box mb-sm-0" style="height: 155px;">
								<div class="box-content px-lg-1 px-xl-5">
									<i class="icon-featured icons icon-cup text-color-primary text-11"></i>
									<h4 class="font-weight-bold text-5 mb-3">Work Hard</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-lg-3 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400" style="animation-delay: 400ms;">
							<div class="featured-box mb-0" style="height: 155px;">
								<div class="box-content px-lg-1 px-xl-5">
									<i class="icon-featured icons icon-heart text-color-primary text-11"></i>
									<h4 class="font-weight-bold text-5 mb-3">Deliver Quality</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
								</div>
							</div>
						</div>
					</div>
				</div>