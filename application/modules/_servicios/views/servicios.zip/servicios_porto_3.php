<section class="section section-no-background section-no-border m-0" id="features">
					<div class="container">
						<div class="row mt-4">
							<div class="col-lg-4">
								<div class="feature-box feature-box-tertiary feature-box-style-5">
									<div class="feature-box-icon">
										<i class="icon-trophy icons"></i>
									</div>
									<div class="feature-box-info">
										<h4 class="mb-2">Award Winning Support</h4>
										<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing metus elit. Quisque rutrum pellentesque imperdiet.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="feature-box feature-box-tertiary feature-box-style-5">
									<div class="feature-box-icon">
										<i class="icon-speedometer icons"></i>
									</div>
									<div class="feature-box-info">
										<h4 class="mb-2">Super Fast</h4>
										<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="feature-box feature-box-tertiary feature-box-style-5">
									<div class="feature-box-icon">
										<i class="icon-cloud-upload icons"></i>
									</div>
									<div class="feature-box-info">
										<h4 class="mb-2">Unlimited Domains</h4>
										<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
									</div>
								</div>
							</div>
						</div>

						<div class="row mt-lg-3 mb-4">
							<div class="col-lg-4">
								<div class="feature-box feature-box-tertiary feature-box-style-5 appear-animation animated fadeInUp appear-animation-visible" data-appear-animation="fadeInUp" data-appear-animation-delay="0" style="animation-delay: 0ms;">
									<div class="feature-box-icon">
										<i class="icon-envelope icons"></i>
									</div>
									<div class="feature-box-info">
										<h4 class="mb-2">FREE Email</h4>
										<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing metus elit. Quisque rutrum pellentesque imperdiet.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="feature-box feature-box-tertiary feature-box-style-5 appear-animation animated fadeInUp appear-animation-visible" data-appear-animation="fadeInUp" data-appear-animation-delay="300" style="animation-delay: 300ms;">
									<div class="feature-box-icon">
										<i class="icon-lock icons"></i>
									</div>
									<div class="feature-box-info">
										<h4 class="mb-2">SSL Certificates</h4>
										<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="feature-box feature-box-tertiary feature-box-style-5 appear-animation animated fadeInUp appear-animation-visible" data-appear-animation="fadeInUp" data-appear-animation-delay="600" style="animation-delay: 600ms;">
									<div class="feature-box-icon">
										<i class="icon-layers icons"></i>
									</div>
									<div class="feature-box-info">
										<h4 class="mb-2">SSD Servers</h4>
										<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
									</div>
								</div>
							</div>
						</div>

					</div>
				</section>