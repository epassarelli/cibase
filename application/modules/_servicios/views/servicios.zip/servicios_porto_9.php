<div class="row pt-5 mt-4 pb-4">
								<div class="col">
									<div class="row pb-4 pt-2 clearfix">
										<div class="col-lg-4">
											<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="400" style="animation-delay: 400ms;">
												<div class="feature-box-icon">
													<i class="icon-user-following icons text-color-primary"></i>
												</div>
												<div class="feature-box-info">
													<h4 class="mb-2">Customer Support</h4>
													<p class="mb-4 text-default">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
												</div>
											</div>
										</div>
										<div class="col-lg-4">
											<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="200" style="animation-delay: 200ms;">
												<div class="feature-box-icon">
													<i class="icon-screen-tablet icons text-color-primary"></i>
												</div>
												<div class="feature-box-info">
													<h4 class="mb-2">Mobile Apps</h4>
													<p class="mb-4 text-default">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
												</div>
											</div>
										</div>
										<div class="col-lg-4">	
											<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" style="animation-delay: 100ms;">
												<div class="feature-box-icon">
													<i class="icon-layers icons text-color-primary"></i>
												</div>
												<div class="feature-box-info">
													<h4 class="mb-2">Sliders</h4>
													<p class="mb-4 text-default">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
												</div>
											</div>
										</div>
									</div>
									<div class="row pb-4">
										<div class="col-lg-4">
											<div class="feature-box feature-box-style-2 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="600" style="animation-delay: 600ms;">
												<div class="feature-box-icon">
													<i class="icon-magnifier icons text-color-primary"></i>
												</div>
												<div class="feature-box-info">
													<h4 class="mb-2">SEO Optimization</h4>
													<p class="mb-4 text-default">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
												</div>
											</div>
										</div>
										<div class="col-lg-4">
											<div class="feature-box feature-box-style-2 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="800" style="animation-delay: 800ms;">
												<div class="feature-box-icon">
													<i class="icon-calculator icons text-color-primary"></i>
												</div>
												<div class="feature-box-info">
													<h4 class="mb-2">HTML5</h4>
													<p class="mb-4 text-default">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
												</div>
											</div>
										</div>
										<div class="col-lg-4">
											<div class="feature-box feature-box-style-2 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="1000" style="animation-delay: 1000ms;">
												<div class="feature-box-icon">
													<i class="icon-star icons text-color-primary"></i>
												</div>
												<div class="feature-box-info">
													<h4 class="mb-2">Icons</h4>
													<p class="mb-4 text-default">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
												</div>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-lg-4">
											<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1600" style="animation-delay: 1600ms;">
												<div class="feature-box-icon">
													<i class="icon-drop icons text-color-primary"></i>
												</div>
												<div class="feature-box-info">
													<h4 class="mb-2">Colors</h4>
													<p class="mb-4 text-default">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
												</div>
											</div>
										</div>
										<div class="col-lg-4">
											<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1400" style="animation-delay: 1400ms;">
												<div class="feature-box-icon">
													<i class="icon-mouse icons text-color-primary"></i>
												</div>
												<div class="feature-box-info">
													<h4 class="mb-2">Buttons</h4>
													<p class="mb-4 text-default">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
												</div>
											</div>
										</div>
										<div class="col-lg-4">
											<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1200" style="animation-delay: 1200ms;">
												<div class="feature-box-icon">
													<i class="icon-screen-desktop icons text-color-primary"></i>
												</div>
												<div class="feature-box-info">
													<h4 class="mb-2">Brand Solutions</h4>
													<p class="mb-4 text-default">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius.</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>