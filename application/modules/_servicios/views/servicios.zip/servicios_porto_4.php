<div class="container my-5 py-3" id="main">
					<div class="row pt-4">
						<div class="col-lg-4 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="200" style="animation-delay: 200ms;">
							<div class="feature-box feature-box-style-2">
								<div class="feature-box-icon">
									<i class="icon-user-following icons"></i>
								</div>
								<div class="feature-box-info">
									<h4 class="font-weight-bold mb-2">Customer Support</h4>
									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing metus elit. Quisque rutrum pellentesque imperdiet.</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 appear-animation animated fadeIn appear-animation-visible" data-appear-animation="fadeIn" style="animation-delay: 100ms;">
							<div class="feature-box feature-box-style-2">
								<div class="feature-box-icon">
									<i class="icon-layers icons"></i>
								</div>
								<div class="feature-box-info">
									<h4 class="font-weight-bold mb-2">Sliders</h4>
									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200" style="animation-delay: 200ms;">
							<div class="feature-box feature-box-style-2">
								<div class="feature-box-icon">
									<i class="icon-calculator icons"></i>
								</div>
								<div class="feature-box-info">
									<h4 class="font-weight-bold mb-2">HTML5</h4>
									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
								</div>
							</div>
						</div>
					</div>

					<div class="row mt-lg-3">
						<div class="col-lg-4">
							<div class="feature-box feature-box-style-2 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="300" style="animation-delay: 300ms;">
								<div class="feature-box-icon">
									<i class="icon-star icons"></i>
								</div>
								<div class="feature-box-info">
									<h4 class="font-weight-bold mb-2">Icons</h4>
									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing metus elit. Quisque rutrum pellentesque imperdiet.</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="feature-box feature-box-style-2 appear-animation animated fadeIn appear-animation-visible" data-appear-animation="fadeIn" data-appear-animation-delay="100" style="animation-delay: 100ms;">
								<div class="feature-box-icon">
									<i class="icon-drop icons"></i>
								</div>
								<div class="feature-box-info">
									<h4 class="font-weight-bold mb-2">Colors</h4>
									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="300" style="animation-delay: 300ms;">
							<div class="feature-box feature-box-style-2">
								<div class="feature-box-icon">
									<i class="icon-mouse icons"></i>
								</div>
								<div class="feature-box-info">
									<h4 class="font-weight-bold mb-2">Buttons</h4>
									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
								</div>
							</div>
						</div>
					</div>

					<div class="row mt-lg-3">
						<div class="col-lg-4 appear-animation animated fadeInLeftShorter appear-animation-visible" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="400" style="animation-delay: 400ms;">
							<div class="feature-box feature-box-style-2">
								<div class="feature-box-icon">
									<i class="icon-screen-desktop icons"></i>
								</div>
								<div class="feature-box-info">
									<h4 class="font-weight-bold mb-2">Lightboxes</h4>
									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing metus elit. Quisque rutrum pellentesque imperdiet.</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 appear-animation animated fadeIn appear-animation-visible" data-appear-animation="fadeIn" data-appear-animation-delay="200" style="animation-delay: 200ms;">
							<div class="feature-box feature-box-style-2">
								<div class="feature-box-icon">
									<i class="icon-energy icons"></i>
								</div>
								<div class="feature-box-info">
									<h4 class="font-weight-bold mb-2">Elements</h4>
									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 appear-animation animated fadeInRightShorter appear-animation-visible" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400" style="animation-delay: 400ms;">
							<div class="feature-box feature-box-style-2">
								<div class="feature-box-icon">
									<i class="icon-social-youtube icons"></i>
								</div>
								<div class="feature-box-info">
									<h4 class="font-weight-bold mb-2">Videos</h4>
									<p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque rutrum pellentesque imperdiet. Nulla lacinia iaculis nulla.</p>
								</div>
							</div>
						</div>
					</div>
				</div>